from pydantic import BaseModel, EmailStr
from typing import Optional
from uuid import UUID

# Schema for user registration
class UserCreate(BaseModel):
    full_name: str
    email: EmailStr
    password: str
    phone: Optional[str] = None
    location: Optional[str] = None
    is_provider: Optional[bool] = False

# Schema for user login
class UserLogin(BaseModel):
    email: EmailStr
    password: str

# Schema for updating user profile
class UserUpdate(BaseModel):
    full_name: Optional[str]
    phone: Optional[str]
    location: Optional[str]

    class Config:
        from_attributes = True

# Response schema
class UserOut(BaseModel):
    id: UUID
    full_name: str
    email: EmailStr
    phone: Optional[str]
    location: Optional[str]
    is_provider: bool

    class Config:
        from_attributes = True
