# app/schemas/provider.py
from pydantic import BaseModel
from typing import Optional, List
from uuid import UUID
from app.schemas.service import ServiceOut  # make sure this exists

class ProviderBase(BaseModel):
    name: str
    category: str
    description: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None

class ProviderPublicOut(BaseModel):
    id: UUID
    name: str
    category: str
    description: Optional[str] = None
    services: List[ServiceOut] = []

    class Config:
        from_attributes = True

class CustomServiceCreate(BaseModel):
    name: str
    description: str
    category: str

class ProviderCreate(ProviderBase):
    service_ids: Optional[List[UUID]] = []
    custom_services: Optional[List[CustomServiceCreate]] = []
    
class ProviderUpdate(ProviderBase):
    service_ids: Optional[List[UUID]] = []

class ProviderOut(ProviderBase):
    id: UUID
    user_id: UUID
    services: List[ServiceOut] = []

    class Config:
        from_attributes = True