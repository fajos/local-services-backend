from pydantic import BaseModel
from uuid import UUID
from datetime import datetime
from typing import Optional

class BookingUpdateStatus(BaseModel):
    status: str  # Only accepts: pending, accepted, completed, canceled

class BookingBase(BaseModel):
    provider_id: UUID
    service_id: UUID
    date: datetime
    note: Optional[str] = None

class BookingCreate(BaseModel):
    provider_id: UUID
    service_id: UUID
    note: Optional[str] = None

class BookingOut(BaseModel):
    id: UUID
    customer_id: UUID
    provider_id: UUID
    provider_name: str
    service_id: UUID
    service_name: str   
    customer_name: str
    customer_phone: str
    customer_location: str
    status: str
    note: Optional[str] = None
    timestamp: datetime

    class Config:
        from_attributes = True