from pydantic import BaseModel
from uuid import UUID
from typing import Optional

class ServiceCreate(BaseModel):
    name: str
    description: str
    category: Optional[str] = None
    provider_id: UUID  # Must point to an existing Provider

class ServiceUpdate(BaseModel):
    name: Optional[str]
    description: Optional[str]
    category: Optional[str]

class ServiceOut(BaseModel):
    id: UUID
    name: str
    description: str
    category: Optional[str]
    provider_id: UUID

    class Config:
        from_attributes = True
